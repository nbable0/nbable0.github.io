$(document).ready(function(){

    $('#menu').on('mouseover',function(){
        $('.wrapper #list li').toggle(1000);
    });
})